package aula4;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

	@Named("turmaBB")
	@SessionScoped
	public class TurmaBB implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 6623271179313349482L;
		private List<Turma> turmas;
		@Inject
	    private Turma turma;

	    @PostConstruct
	    public void init() {
	        turma = new Turma();
	        
	        this.turmas = TurmaHibernate.listar();
	       
	    }

		public List<Turma> getTurmas() {
			return turmas;
		}

		public void setTurmas(List<Turma> turmas) {
			this.turmas = turmas;
		}

		public Turma getTurma() {
			return turma;
		}

		public void setTurma(Turma turma) {
			this.turma = turma;
		}
		
		public String addTurma() {
			TurmaHibernate.adicionar(turma);
			turma = new Turma();
			this.turmas = TurmaHibernate.listar();
			return "turmas";
		}
		
		public void remover(Turma t) {
			TurmaHibernate.remover(t);
			this.turmas = TurmaHibernate.listar();
		}
		
		public String alterar(Turma t) {
			this.turma = TurmaHibernate.ver(t.getId());
			return "editarTurma";
			
		}
		
		public String alterarTurma() {
			TurmaHibernate.alterar(this.turma);
			this.turmas = TurmaHibernate.listar();
			this.turma = new Turma();
			return "turmas";
		}
		
}

