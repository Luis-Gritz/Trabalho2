package aula4;

import java.util.HashSet;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Named
@RequestScoped
@Entity
@Table(name="turma")
public class Turma {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
    private Long id;
	
	@Column(name="nome")
	private String nome;
	
	@Inject
	@ManyToOne
	@JoinColumn(name="professorID")
	private Professor professor = new Professor();
	@Inject
	@ManyToOne
	@JoinColumn(name="disciplinaID")
	private Disciplina disciplina = new Disciplina();
	@ManyToMany
	@JoinTable(name="alunosTurma",
	joinColumns={@JoinColumn(name="turmaID")},
	inverseJoinColumns={@JoinColumn(name="alunoID")})
	private Set<Aluno> alunos = new HashSet<Aluno>();
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Professor getProfessor() {
		return professor;
	}
	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	public Disciplina getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
	public Set<Aluno> getAlunos() {
		return alunos;
	}
	public void setAlunos(Set<Aluno> alunos) {
		this.alunos = alunos;
	}
	
	
}
