package aula4;


import java.io.Serializable;
import java.util.List;
import java.util.Vector;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("alunoBB")
@SessionScoped
public class AlunoBB implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6623271179313349482L;
	private List<Aluno> alunos;
	@Inject
    private Aluno aluno;

    @PostConstruct
    public void init() {
        aluno = new Aluno();
        
        this.alunos = AlunoHibernate.listar();
        
       /* for (Aluno vAluno : alunos) {
			System.out.println("ra " + vAluno.getRa());
		}*/
        
    }

	public List<Aluno> getAlunos() {
		return alunos;
	}

	public void setAlunos(List<Aluno> alunos) {
		this.alunos = alunos;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	
	public String addAluno() {
		//this.alunos.add(aluno);
		//AlunoDAO.adicionar(aluno);
		aluno.getEndereco().setAluno(aluno);
		AlunoHibernate.adicionar(aluno);
		aluno = new Aluno();
		this.alunos = AlunoHibernate.listar();
		return "resposta";
	}
	
	public void remover(Aluno a) {
		System.out.println(a.getEndereco().getId());
		//this.alunos.remove(a);
		AlunoHibernate.remover(a);
		this.alunos = AlunoHibernate.listar();
	}
	
	public String alterar(Aluno a) {
		this.aluno = AlunoHibernate.ver(a.getId());
		return "editar";
		
	}
	
	public String alterarAluno() {
		AlunoHibernate.alterar(this.aluno);
		this.alunos = AlunoHibernate.listar();
		this.aluno = new Aluno();
		return "resposta";
	}
    
    
}
