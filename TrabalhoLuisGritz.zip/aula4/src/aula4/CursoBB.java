package aula4;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("cursoBB")
@SessionScoped
public class CursoBB  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2111460311975649999L;
	private List<Curso> cursos;
	@Inject
    private Curso curso;

    @PostConstruct
    public void init() {
        curso = new Curso();
        
        this.cursos = CursoHibernate.listar();        
        
    }

	public List<Curso> getCursos() {
		return cursos;
	}

	public void setCursos(List<Curso> cursos) {
		this.cursos = cursos;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}
    
	public String addCurso() {
		CursoHibernate.adicionar(curso);
		curso = new Curso();
		this.cursos = CursoHibernate.listar();
		return "cursos";
	}
	
	public void remover(Curso c) {
		CursoHibernate.remover(c);
		this.cursos = CursoHibernate.listar();
	}
	
	public String alterar(Curso c) {
		this.curso = CursoHibernate.ver(c.getId());
		return "editarCurso";
		
	}
	
	public String alterarCurso() {
		CursoHibernate.alterar(this.curso);
		this.cursos = CursoHibernate.listar();
		this.curso = new Curso();
		return "cursos";
	}
}
