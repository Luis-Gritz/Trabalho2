package aula4;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class TurmaHibernate {

	public static void adicionar(Turma turma) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.save(turma);
			//sessao.save(turma.getAlunos());
			//sessao.save(turma.getDisciplina());
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void alterar(Turma turma) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.update(turma);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void remover(Turma turma) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.delete(turma);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static Turma ver(Long id) {
		Session sessao = null;
		Transaction transacao = null;
		Turma turma = null;
		Query<Turma> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Turma where id = :id", Turma.class);
			consulta.setParameter("id", id);
			turma = consulta.uniqueResult();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return turma;
	}
	
	public static List<Turma> listar() {
		Session sessao = null;
		Transaction transacao = null;
		List<Turma> turmas = null;
		Query<Turma> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Turma", Turma.class);
			turmas = consulta.list();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return turmas;
	}
}
