package aula4;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class ProfessorHibernate {

	public static void adicionar(Professor professor) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.save(professor);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void alterar(Professor professor) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.update(professor);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void remover(Professor professor) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.delete(professor);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static Professor ver(Long id) {
		Session sessao = null;
		Transaction transacao = null;
		Professor professor = null;
		Query<Professor> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Professor where id = :id", Professor.class);
			consulta.setParameter("id", id);
			professor = consulta.uniqueResult();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return professor;
	}
	
	public static List<Professor> listar() {
		Session sessao = null;
		Transaction transacao = null;
		List<Professor> professores = null;
		Query<Professor> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Professor", Professor.class);
			professores = consulta.list();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return professores;
	}
}
