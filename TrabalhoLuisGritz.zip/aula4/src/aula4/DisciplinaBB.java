package aula4;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("disciplinaBB")
@SessionScoped
public class DisciplinaBB implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6623271179313349482L;
	private List<Disciplina> disciplinas;
	@Inject
    private Disciplina disciplina;

    @PostConstruct
    public void init() {
    	disciplina = new Disciplina();
        
        this.disciplinas = DisciplinaHibernete.listar();

        
    }

	public List<Disciplina> getDisciplinas() {
		return disciplinas;
	}

	public void setDisciplinas(List<Disciplina> disciplinas) {
		this.disciplinas = disciplinas;
	}

	public Disciplina getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
	
	public String addDisciplina() {
		DisciplinaHibernete.adicionar(disciplina);
		disciplina = new Disciplina();
		this.disciplinas = DisciplinaHibernete.listar();
		return "disciplinas";
	}
	
	public void remover(Disciplina d) {
		DisciplinaHibernete.remover(d);
		this.disciplinas = DisciplinaHibernete.listar();
	}
	
	public String alterar(Disciplina d) {
		this.disciplina = DisciplinaHibernete.ver(d.getId());
		return "editarDisciplina";
		
	}
	
	public String alterarDisciplina() {
		DisciplinaHibernete.alterar(this.disciplina);
		this.disciplinas = DisciplinaHibernete.listar();
		this.disciplina = new Disciplina();
		return "disciplinas";
	}
    
    
}

