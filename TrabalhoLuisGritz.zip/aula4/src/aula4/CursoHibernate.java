package aula4;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class CursoHibernate {
	
	public static void adicionar(Curso curso) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.save(curso);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void alterar(Curso curso) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.update(curso);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void remover(Curso curso) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.delete(curso);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static Curso ver(Long id) {
		Session sessao = null;
		Transaction transacao = null;
		Curso curso = null;
		Query<Curso> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Curso where id = :id", Curso.class);
			consulta.setParameter("id", id);
			curso = consulta.uniqueResult();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return curso;
	}
	
	public static List<Curso> listar() {
		Session sessao = null;
		Transaction transacao = null;
		List<Curso> cursos = null;
		Query<Curso> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Curso", Curso.class);
			cursos = consulta.list();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return cursos;
	}
}
