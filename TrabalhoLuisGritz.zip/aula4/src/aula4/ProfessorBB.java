package aula4;


import java.io.Serializable;
import java.util.List;
import java.util.Vector;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("professorBB")
@SessionScoped
public class ProfessorBB implements Serializable {

	private static final long serialVersionUID = 4720986433743054369L;
	private List<Professor> professores;
	@Inject
    private Professor professor;

    @PostConstruct
    public void init() {
    	professor = new Professor();
        this.professores = ProfessorHibernate.listar();
        
        
    }
    
    
	
	public List<Professor> getProfessores() {
		return professores;
	}



	public void setProfessores(List<Professor> professores) {
		this.professores = professores;
	}



	public Professor getProfessor() {
		return professor;
	}



	public void setProfessor(Professor professor) {
		this.professor = professor;
	}



	public String addProfessor() {
		ProfessorHibernate.adicionar(professor);
		professor = new Professor();
		this.professores = ProfessorHibernate.listar();
		return "professores";
	}
	
	public void remover(Professor a) {
		ProfessorHibernate.remover(a);
		this.professores = ProfessorHibernate.listar();
	}
	
	public String alterar(Professor a) {
		this.professor = ProfessorHibernate.ver(a.getId());		
		return "editarProfessor";
		
	}
	
	public String alterarProfessor() {
		
		ProfessorHibernate.alterar(this.professor);
		
		this.professores = ProfessorHibernate.listar();
		this.professor = new Professor();
				
		return "professores";
	}
    
    
}
