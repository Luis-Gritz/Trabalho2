package aula4;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.*;
import javax.validation.constraints.*;

@Named("aluno")
@RequestScoped
@Entity
@Table(name="aluno")
public class Aluno implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 748403681903932707L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
    private Long id;
	@Column(name="ra")
	private String ra;
	@Size(min=2, max=30, message="Nome precisa ter entre 2 a 30 caracteres")	
	@Column(name="nome")
	private String nome;
	@Column(name="sobrenome")
	private String sobrenome;
	@Column(name="email")
	private String email;
	
	@Inject
	@OneToOne
	@PrimaryKeyJoinColumn(name="id")
	private Endereco endereco = new Endereco();
	
	private String genero;
	@Column(name="nota1")
	private Float nota1 = 0.0f;
	@Column(name="nota2")
	private Float nota2 = 0.0f;
	@Column(name="nota3")
	private Float nota3 = 0.0f;

	@Inject
	@ManyToOne
	@JoinColumn(name="cursoID")
	private Curso curso = new Curso();	
	
	@ManyToMany
	@JoinTable(name="alunosTurma",
	joinColumns={@JoinColumn(name="alunoID")},
	inverseJoinColumns={@JoinColumn(name="turmaID")})
	private Set<Aluno> alunos = new HashSet<Aluno>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Aluno() { 
	}
	
	public Aluno(String ra, String nome, String sobrenome) {    
		this.ra = ra;    
		this.nome = nome;    
		this.sobrenome = sobrenome;    
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getRa() {
		return ra;
	}

	public void setRa(String ra) {
		this.ra = ra;
	}

	public Float getNota1() {
		return nota1;
	}

	public void setNota1(Float nota1) {
		this.nota1 = nota1;
	}

	public Float getNota2() {
		return nota2;
	}

	public void setNota2(Float nota2) {
		this.nota2 = nota2;
	}

	public Float getNota3() {
		return nota3;
	}
	
	public Float getMedia() {
		return (nota1 + nota2 + nota3) / 3;
	}

	public void setNota3(Float nota3) {
		this.nota3 = nota3;
	}


	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
			
	
}
