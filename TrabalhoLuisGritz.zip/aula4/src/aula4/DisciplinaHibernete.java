package aula4;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class DisciplinaHibernete {
	
	public static void adicionar(Disciplina disciplina) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.save(disciplina);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void alterar(Disciplina disciplina) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.update(disciplina);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void remover(Disciplina disciplina) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.delete(disciplina);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static Disciplina ver(Long id) {
		Session sessao = null;
		Transaction transacao = null;
		Disciplina disciplina = null;
		Query<Disciplina> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Disciplina where id = :id", Disciplina.class);
			consulta.setParameter("id", id);
			disciplina = consulta.uniqueResult();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return disciplina;
	}
	
	public static List<Disciplina> listar() {
		Session sessao = null;
		Transaction transacao = null;
		List<Disciplina> disciplinas = null;
		Query<Disciplina> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Disciplina", Disciplina.class);
			disciplinas = consulta.list();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return disciplinas;
	}

}
