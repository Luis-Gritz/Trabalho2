package aula4;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Parameter;

@Named("endereco")
@RequestScoped
@Entity
@Table(name="endereco")
public class Endereco implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6337689805549783533L;
	@Id
	@GeneratedValue(generator = "fk_endereco_aluno")
	@org.hibernate.annotations.
		GenericGenerator(name = "fk_endereco_aluno",
		strategy="foreign", parameters = @Parameter(name = "property",
		value="aluno"))
	@Column(name="id")
	private Long id;
	@Column(name="logradouro")
	private String logradouro;
	
	@OneToOne(mappedBy = "endereco")
	private Aluno aluno;
		

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	
	
	
	
	
}
