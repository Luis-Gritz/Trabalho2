package aula4;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class AlunoHibernate {
	
	public static void adicionar(Aluno aluno) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.save(aluno);
			sessao.save(aluno.getEndereco());
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void alterar(Aluno aluno) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.update(aluno);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static void remover(Aluno aluno) {
		Session sessao = null;
		Transaction transacao = null;
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			sessao.delete(aluno);
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static Aluno ver(Long id) {
		Session sessao = null;
		Transaction transacao = null;
		Aluno aluno = null;
		Query<Aluno> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Aluno where id = :id", Aluno.class);
			consulta.setParameter("id", id);
			aluno = consulta.uniqueResult();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return aluno;
	}
	
	public static List<Aluno> listar() {
		Session sessao = null;
		Transaction transacao = null;
		List<Aluno> alunos = null;
		Query<Aluno> consulta = null; 
		
		try {
			sessao = HibernateUtil.getSessionFactory().openSession();
			transacao = sessao.beginTransaction();
			consulta = sessao.createQuery("from Aluno", Aluno.class);
			alunos = consulta.list();
			transacao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				sessao.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return alunos;
	}
}
